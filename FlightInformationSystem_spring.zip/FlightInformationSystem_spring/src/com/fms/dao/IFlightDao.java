package com.fms.dao;

import com.fms.bean.FlightBean;

public interface IFlightDao {
	public int addFlightDetails(FlightBean f);
}
