package com.cg.bean;

public class BankingApp {
	String custName;
	String address;
	String emailid;
	int idProof;
	String custMobNo;
	int custAge;
	int accountNo;
	int accPin;
	int balance;
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAccPin() {
		return accPin;
	}
	public void setAccPin(int accPin) {
		this.accPin = accPin;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public int getIdProof() {
		return idProof;
	}
	public void setIdProof(int idProof) {
		this.idProof = idProof;
	}
	public String getCustMobNo() {
		return custMobNo;
	}
	public void setCustMobNo(String custMobNo) {
		this.custMobNo = custMobNo;
	}
	public int getCustAge() {
		return custAge;
	}
	public void setCustAge(int custAge) {
		this.custAge = custAge;
	}
	@Override
	public String toString() {
		return "Customer: "+ "\n" + "[custName=" + custName + ", address=" + address+"\n"
				+ ", emailid=" + emailid + ", idProof=" + idProof+"\n"
				+ ", custMobNo=" + custMobNo + ", custAge=" + custAge+"\n"
				+ ", accountNo=" + accountNo + ", accPin=" + accPin+"\n"
				+ ", balance=" + balance + "]";
	}
	
	
	
	
	

}
