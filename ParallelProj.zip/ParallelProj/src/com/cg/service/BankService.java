package com.cg.service;

import com.cg.dao.BankDao;
import com.cg.dao.IBankDao;

import java.util.Map;

import com.cg.bean.BankingApp;

public class BankService implements IBankService {
	
	BankDao dao=null;
	
	public boolean addCustomer(BankingApp bean) {
		// TODO Auto-generated method stub
		dao=new BankDao();
		return dao.addCustomer(bean);
	}
	public Map<Integer,BankingApp> getAll(){
		dao=new BankDao();
		return dao.getAll();
	}
}

