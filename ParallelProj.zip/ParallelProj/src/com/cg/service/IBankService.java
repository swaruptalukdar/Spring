package com.cg.service;

import java.util.Map;

import com.cg.bean.BankingApp;

public interface IBankService {
	public boolean addCustomer(BankingApp bean);
	public Map<Integer,BankingApp> getAll();
}
