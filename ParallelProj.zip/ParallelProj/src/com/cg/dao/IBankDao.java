package com.cg.dao;

import java.util.Map;

import com.cg.bean.BankingApp;

public interface IBankDao {
	
	public boolean addCustomer(BankingApp bean);
	public Map<Integer,BankingApp> getAll();
}
