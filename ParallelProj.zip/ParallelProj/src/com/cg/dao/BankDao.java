package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.BankingApp;

public class BankDao implements IBankDao {

static Map<Integer, BankingApp> empMap = new HashMap<Integer, BankingApp>();

	public boolean addCustomer(BankingApp bean) {
		boolean isAdded=false;
		System.out.println("no data "+empMap);
			empMap.put(bean.getAccountNo(),bean);
			System.out.println("after added "+empMap);
			
			isAdded=true;
		return isAdded;
	}
	public Map<Integer,BankingApp> getAll(){
		System.out.println("in get all "+empMap);
		return empMap;
	}
	
	/*public boolean addCustomer(BankingApp bean) {
		boolean isAdded = false;
		
		empMap.put(bean.getAccountNo(), bean);
		System.out.println("this is bean" +  bean.getAccountNo());
		// System.out.println(empMap);
		isAdded = true;
		// isAdded = custList.add(c);
		return isAdded;
	}*/

	

}
