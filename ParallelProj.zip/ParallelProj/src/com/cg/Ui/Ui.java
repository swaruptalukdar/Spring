package com.cg.Ui;

import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.cg.bean.BankingApp;
import com.cg.dao.BankDao;
import com.cg.dao.IBankDao;
import com.cg.service.BankService;
import com.cg.service.IBankService;

public class Ui {
	
	static IBankService ib=null;
	
	public static void main(String ar[]) {
		
while(true) {
	System.out.println("Welcome");
	System.out.println("1.Create Account");
	System.out.println("2.get all data");
	System.out.println("3.Exit");
	System.out.println("Enter your Choice");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		ib=new BankService();
		
		switch (choice) {

		case 1:
			System.out.println("Enter your Name:");
			String custName = sc.next();
			System.out.println("Enter your Address:");
			String address = sc.next();
			System.out.println("Enter your email id:");
			String emailid = sc.next();
			System.out.println("Enter idProof number");
			int idProof = sc.nextInt();

			System.out.println("Enter mobile number");
			String custMobNo = sc.next();

			System.out.println("Enter your age:");
			int custAge = sc.nextInt();
			System.out.println("Enter minimum balance amount you wish to keep");
			int balance = sc.nextInt();
			BankingApp bean=new BankingApp();
			bean.setBalance(balance);
			bean.setAddress(address);
			bean.setCustAge(custAge);
			bean.setCustName(custName);
			bean.setEmailid(emailid);
			bean.setIdProof(idProof);
			bean.setCustMobNo(custMobNo);
			Random rd1 = new Random();
			int accountNo = 100000 + rd1.nextInt(90000);
			bean.setAccountNo(accountNo);
			Random rd2 = new Random();
			int accPin = 1000 + rd2.nextInt(90000);
			bean.setAccPin(accPin);
			boolean b=ib.addCustomer(bean);
			if(b)
				System.out.println("added");
			break;
		case 2:
			System.out.println("in 2");
			Map<Integer, BankingApp> ll=ib.getAll();
			ll.values().stream().forEach(System.out::println);
			break;
		}
	}

	}
}
