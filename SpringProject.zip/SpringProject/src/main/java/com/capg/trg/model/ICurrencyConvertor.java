package com.capg.trg.model;

public interface ICurrencyConvertor 
{
	public abstract double dollarToRupees(double dollars);
}
